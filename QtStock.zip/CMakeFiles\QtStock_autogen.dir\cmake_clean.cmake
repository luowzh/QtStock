file(REMOVE_RECURSE
  "QtStock_autogen"
  "CMakeFiles/QtStock_autogen.dir/AutogenOldSettings.txt"
  "CMakeFiles/QtStock_autogen"
  "QtStock_autogen/mocs_compilation.cpp"
)

# Per-language clean rules from dependency scanning.
foreach(lang )
  include(CMakeFiles/QtStock_autogen.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
