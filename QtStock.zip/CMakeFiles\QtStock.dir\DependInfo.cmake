# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "CXX"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_CXX
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/QtStock_autogen/mocs_compilation.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/QtStock_autogen/mocs_compilation.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/core/csv_loader.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/core/csv_loader.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/core/dataengine.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/core/dataengine.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/core/sina_api.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/core/sina_api.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/indicator/boll.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/indicator/boll.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/indicator/ma.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/indicator/ma.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/indicator/macd.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/indicator/macd.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/main.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/main.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/view/kline_view.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/view/kline_view.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/view/mainwindow.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/view/mainwindow.cpp.obj"
  "C:/Users/pkuts/Downloads/QtStock-main/QtStock/src/view/stock_list.cpp" "C:/Users/pkuts/Downloads/QtStock-main/QtStock/build/CMakeFiles/QtStock.dir/src/view/stock_list.cpp.obj"
  )
set(CMAKE_CXX_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_CXX
  "QT_CHARTS_LIB"
  "QT_CORE_LIB"
  "QT_GUI_LIB"
  "QT_NETWORK_LIB"
  "QT_NO_DEBUG"
  "QT_WIDGETS_LIB"
  )

# The include file search paths:
set(CMAKE_CXX_TARGET_INCLUDE_PATH
  "QtStock_autogen/include"
  "../src"
  "../src/core"
  "../src/view"
  "../src/indicator"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtWidgets"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtGui"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtANGLE"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtCore"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/./mkspecs/win32-g++"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtNetwork"
  "D:/Qt/Qt5.14.2/5.14.2/mingw73_32/include/QtCharts"
  )

# Targets to which this target links.
set(CMAKE_TARGET_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
