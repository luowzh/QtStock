/****************************************************************************
** Meta object code from reading C++ file 'dataengine.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../src/core/dataengine.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'dataengine.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_DataEngine_t {
    QByteArrayData data[15];
    char stringdata0[170];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_DataEngine_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_DataEngine_t qt_meta_stringdata_DataEngine = {
    {
QT_MOC_LITERAL(0, 0, 10), // "DataEngine"
QT_MOC_LITERAL(1, 11, 13), // "quotesUpdated"
QT_MOC_LITERAL(2, 25, 0), // ""
QT_MOC_LITERAL(3, 26, 17), // "QList<StockQuote>"
QT_MOC_LITERAL(4, 44, 6), // "quotes"
QT_MOC_LITERAL(5, 51, 14), // "klinesReceived"
QT_MOC_LITERAL(6, 66, 4), // "code"
QT_MOC_LITERAL(7, 71, 12), // "QList<KLine>"
QT_MOC_LITERAL(8, 84, 6), // "klines"
QT_MOC_LITERAL(9, 91, 16), // "stockListChanged"
QT_MOC_LITERAL(10, 108, 13), // "errorOccurred"
QT_MOC_LITERAL(11, 122, 3), // "msg"
QT_MOC_LITERAL(12, 126, 16), // "onQuotesReceived"
QT_MOC_LITERAL(13, 143, 16), // "onKLinesReceived"
QT_MOC_LITERAL(14, 160, 9) // "onTimeout"

    },
    "DataEngine\0quotesUpdated\0\0QList<StockQuote>\0"
    "quotes\0klinesReceived\0code\0QList<KLine>\0"
    "klines\0stockListChanged\0errorOccurred\0"
    "msg\0onQuotesReceived\0onKLinesReceived\0"
    "onTimeout"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_DataEngine[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x06 /* Public */,
       5,    2,   52,    2, 0x06 /* Public */,
       9,    0,   57,    2, 0x06 /* Public */,
      10,    1,   58,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      12,    1,   61,    2, 0x08 /* Private */,
      13,    2,   64,    2, 0x08 /* Private */,
      14,    0,   69,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 7,    6,    8,
    QMetaType::Void,
    QMetaType::Void, QMetaType::QString,   11,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 7,    6,    8,
    QMetaType::Void,

       0        // eod
};

void DataEngine::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<DataEngine *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->quotesUpdated((*reinterpret_cast< const QList<StockQuote>(*)>(_a[1]))); break;
        case 1: _t->klinesReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QList<KLine>(*)>(_a[2]))); break;
        case 2: _t->stockListChanged(); break;
        case 3: _t->errorOccurred((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onQuotesReceived((*reinterpret_cast< const QList<StockQuote>(*)>(_a[1]))); break;
        case 5: _t->onKLinesReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QList<KLine>(*)>(_a[2]))); break;
        case 6: _t->onTimeout(); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (DataEngine::*)(const QList<StockQuote> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataEngine::quotesUpdated)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (DataEngine::*)(const QString & , const QList<KLine> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataEngine::klinesReceived)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (DataEngine::*)();
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataEngine::stockListChanged)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (DataEngine::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&DataEngine::errorOccurred)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject DataEngine::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_DataEngine.data,
    qt_meta_data_DataEngine,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *DataEngine::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *DataEngine::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_DataEngine.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int DataEngine::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void DataEngine::quotesUpdated(const QList<StockQuote> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void DataEngine::klinesReceived(const QString & _t1, const QList<KLine> & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void DataEngine::stockListChanged()
{
    QMetaObject::activate(this, &staticMetaObject, 2, nullptr);
}

// SIGNAL 3
void DataEngine::errorOccurred(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
