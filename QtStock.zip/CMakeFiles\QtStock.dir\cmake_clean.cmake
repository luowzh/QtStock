file(REMOVE_RECURSE
  "QtStock_autogen"
  "CMakeFiles/QtStock_autogen.dir/AutogenOldSettings.txt"
  "CMakeFiles/QtStock.dir/QtStock_autogen/mocs_compilation.cpp.obj"
  "CMakeFiles/QtStock.dir/src/main.cpp.obj"
  "CMakeFiles/QtStock.dir/src/core/sina_api.cpp.obj"
  "CMakeFiles/QtStock.dir/src/core/dataengine.cpp.obj"
  "CMakeFiles/QtStock.dir/src/core/csv_loader.cpp.obj"
  "CMakeFiles/QtStock.dir/src/view/mainwindow.cpp.obj"
  "CMakeFiles/QtStock.dir/src/view/stock_list.cpp.obj"
  "CMakeFiles/QtStock.dir/src/view/kline_view.cpp.obj"
  "CMakeFiles/QtStock.dir/src/indicator/ma.cpp.obj"
  "CMakeFiles/QtStock.dir/src/indicator/macd.cpp.obj"
  "CMakeFiles/QtStock.dir/src/indicator/boll.cpp.obj"
  "QtStock.pdb"
  "QtStock.exe"
  "QtStock.exe.manifest"
  "libQtStock.dll.a"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/QtStock.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
