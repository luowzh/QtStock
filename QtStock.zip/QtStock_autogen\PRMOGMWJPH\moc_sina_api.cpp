/****************************************************************************
** Meta object code from reading C++ file 'sina_api.h'
**
** Created by: The Qt Meta Object Compiler version 67 (Qt 5.14.2)
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <memory>
#include "../../../src/core/sina_api.h"
#include <QtCore/qbytearray.h>
#include <QtCore/qmetatype.h>
#include <QtCore/QList>
#if !defined(Q_MOC_OUTPUT_REVISION)
#error "The header file 'sina_api.h' doesn't include <QObject>."
#elif Q_MOC_OUTPUT_REVISION != 67
#error "This file was generated using the moc from 5.14.2. It"
#error "cannot be used with the include files from this version of Qt."
#error "(The moc has changed too much.)"
#endif

QT_BEGIN_MOC_NAMESPACE
QT_WARNING_PUSH
QT_WARNING_DISABLE_DEPRECATED
struct qt_meta_stringdata_SinaAPI_t {
    QByteArrayData data[19];
    char stringdata0[217];
};
#define QT_MOC_LITERAL(idx, ofs, len) \
    Q_STATIC_BYTE_ARRAY_DATA_HEADER_INITIALIZER_WITH_OFFSET(len, \
    qptrdiff(offsetof(qt_meta_stringdata_SinaAPI_t, stringdata0) + ofs \
        - idx * sizeof(QByteArrayData)) \
    )
static const qt_meta_stringdata_SinaAPI_t qt_meta_stringdata_SinaAPI = {
    {
QT_MOC_LITERAL(0, 0, 7), // "SinaAPI"
QT_MOC_LITERAL(1, 8, 14), // "quotesReceived"
QT_MOC_LITERAL(2, 23, 0), // ""
QT_MOC_LITERAL(3, 24, 17), // "QList<StockQuote>"
QT_MOC_LITERAL(4, 42, 6), // "quotes"
QT_MOC_LITERAL(5, 49, 14), // "klinesReceived"
QT_MOC_LITERAL(6, 64, 4), // "code"
QT_MOC_LITERAL(7, 69, 12), // "QList<KLine>"
QT_MOC_LITERAL(8, 82, 6), // "klines"
QT_MOC_LITERAL(9, 89, 19), // "timeSharingReceived"
QT_MOC_LITERAL(10, 109, 18), // "QList<TimeSharing>"
QT_MOC_LITERAL(11, 128, 4), // "data"
QT_MOC_LITERAL(12, 133, 13), // "errorOccurred"
QT_MOC_LITERAL(13, 147, 3), // "msg"
QT_MOC_LITERAL(14, 151, 12), // "onQuoteReply"
QT_MOC_LITERAL(15, 164, 14), // "QNetworkReply*"
QT_MOC_LITERAL(16, 179, 5), // "reply"
QT_MOC_LITERAL(17, 185, 12), // "onKLineReply"
QT_MOC_LITERAL(18, 198, 18) // "onTimeSharingReply"

    },
    "SinaAPI\0quotesReceived\0\0QList<StockQuote>\0"
    "quotes\0klinesReceived\0code\0QList<KLine>\0"
    "klines\0timeSharingReceived\0"
    "QList<TimeSharing>\0data\0errorOccurred\0"
    "msg\0onQuoteReply\0QNetworkReply*\0reply\0"
    "onKLineReply\0onTimeSharingReply"
};
#undef QT_MOC_LITERAL

static const uint qt_meta_data_SinaAPI[] = {

 // content:
       8,       // revision
       0,       // classname
       0,    0, // classinfo
       7,   14, // methods
       0,    0, // properties
       0,    0, // enums/sets
       0,    0, // constructors
       0,       // flags
       4,       // signalCount

 // signals: name, argc, parameters, tag, flags
       1,    1,   49,    2, 0x06 /* Public */,
       5,    2,   52,    2, 0x06 /* Public */,
       9,    2,   57,    2, 0x06 /* Public */,
      12,    1,   62,    2, 0x06 /* Public */,

 // slots: name, argc, parameters, tag, flags
      14,    1,   65,    2, 0x08 /* Private */,
      17,    1,   68,    2, 0x08 /* Private */,
      18,    1,   71,    2, 0x08 /* Private */,

 // signals: parameters
    QMetaType::Void, 0x80000000 | 3,    4,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 7,    6,    8,
    QMetaType::Void, QMetaType::QString, 0x80000000 | 10,    6,   11,
    QMetaType::Void, QMetaType::QString,   13,

 // slots: parameters
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void, 0x80000000 | 15,   16,
    QMetaType::Void, 0x80000000 | 15,   16,

       0        // eod
};

void SinaAPI::qt_static_metacall(QObject *_o, QMetaObject::Call _c, int _id, void **_a)
{
    if (_c == QMetaObject::InvokeMetaMethod) {
        auto *_t = static_cast<SinaAPI *>(_o);
        Q_UNUSED(_t)
        switch (_id) {
        case 0: _t->quotesReceived((*reinterpret_cast< const QList<StockQuote>(*)>(_a[1]))); break;
        case 1: _t->klinesReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QList<KLine>(*)>(_a[2]))); break;
        case 2: _t->timeSharingReceived((*reinterpret_cast< const QString(*)>(_a[1])),(*reinterpret_cast< const QList<TimeSharing>(*)>(_a[2]))); break;
        case 3: _t->errorOccurred((*reinterpret_cast< const QString(*)>(_a[1]))); break;
        case 4: _t->onQuoteReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 5: _t->onKLineReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        case 6: _t->onTimeSharingReply((*reinterpret_cast< QNetworkReply*(*)>(_a[1]))); break;
        default: ;
        }
    } else if (_c == QMetaObject::IndexOfMethod) {
        int *result = reinterpret_cast<int *>(_a[0]);
        {
            using _t = void (SinaAPI::*)(const QList<StockQuote> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SinaAPI::quotesReceived)) {
                *result = 0;
                return;
            }
        }
        {
            using _t = void (SinaAPI::*)(const QString & , const QList<KLine> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SinaAPI::klinesReceived)) {
                *result = 1;
                return;
            }
        }
        {
            using _t = void (SinaAPI::*)(const QString & , const QList<TimeSharing> & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SinaAPI::timeSharingReceived)) {
                *result = 2;
                return;
            }
        }
        {
            using _t = void (SinaAPI::*)(const QString & );
            if (*reinterpret_cast<_t *>(_a[1]) == static_cast<_t>(&SinaAPI::errorOccurred)) {
                *result = 3;
                return;
            }
        }
    }
}

QT_INIT_METAOBJECT const QMetaObject SinaAPI::staticMetaObject = { {
    QMetaObject::SuperData::link<QObject::staticMetaObject>(),
    qt_meta_stringdata_SinaAPI.data,
    qt_meta_data_SinaAPI,
    qt_static_metacall,
    nullptr,
    nullptr
} };


const QMetaObject *SinaAPI::metaObject() const
{
    return QObject::d_ptr->metaObject ? QObject::d_ptr->dynamicMetaObject() : &staticMetaObject;
}

void *SinaAPI::qt_metacast(const char *_clname)
{
    if (!_clname) return nullptr;
    if (!strcmp(_clname, qt_meta_stringdata_SinaAPI.stringdata0))
        return static_cast<void*>(this);
    return QObject::qt_metacast(_clname);
}

int SinaAPI::qt_metacall(QMetaObject::Call _c, int _id, void **_a)
{
    _id = QObject::qt_metacall(_c, _id, _a);
    if (_id < 0)
        return _id;
    if (_c == QMetaObject::InvokeMetaMethod) {
        if (_id < 7)
            qt_static_metacall(this, _c, _id, _a);
        _id -= 7;
    } else if (_c == QMetaObject::RegisterMethodArgumentMetaType) {
        if (_id < 7)
            *reinterpret_cast<int*>(_a[0]) = -1;
        _id -= 7;
    }
    return _id;
}

// SIGNAL 0
void SinaAPI::quotesReceived(const QList<StockQuote> & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 0, _a);
}

// SIGNAL 1
void SinaAPI::klinesReceived(const QString & _t1, const QList<KLine> & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 1, _a);
}

// SIGNAL 2
void SinaAPI::timeSharingReceived(const QString & _t1, const QList<TimeSharing> & _t2)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))), const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t2))) };
    QMetaObject::activate(this, &staticMetaObject, 2, _a);
}

// SIGNAL 3
void SinaAPI::errorOccurred(const QString & _t1)
{
    void *_a[] = { nullptr, const_cast<void*>(reinterpret_cast<const void*>(std::addressof(_t1))) };
    QMetaObject::activate(this, &staticMetaObject, 3, _a);
}
QT_WARNING_POP
QT_END_MOC_NAMESPACE
